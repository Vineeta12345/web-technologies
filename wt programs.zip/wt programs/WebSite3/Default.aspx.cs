﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    { }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string connetionString;
        SqlConnection cnn;
        connetionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Emp_Detail;Integrated Security=True";
        cnn = new SqlConnection(connetionString);
        cnn.Open();
        Response.Write("Connection MAde");
        string SQLCommand = "Insert into dbo.Table_1(student_firstname,student_lastname,course_name,course_code,why_choosecourse, content_metexpectation,lecsequence_planned,content_illustrated,level_course,content_compared expectation,course_exposed,recommend_course,lecture_understand,teachingaid_effective,materi al_adequate,teacher_encouragement,objective_courserealised,overall_rating,suggestions)values( " + "'" + this.TextBox1.Text + "','" + this.TextBox2.Text + "','" + this.TextBox3.Text + "','" + this.TextBox4.Text + "','" + this.DropDownList1.SelectedItem.Value + "','" + this.DropDownList2.SelectedItem.Value + "','" + this.DropDownList3.SelectedItem.Value + "','" + this.DropDownList4.SelectedItem.Value + "','" + this.DropDownList5.SelectedItem.Value + "','" + this.DropDownList6.SelectedItem.Value + "','" + this.DropDownList7.SelectedItem.Value + "','" + this.DropDownList8.SelectedItem.Value + "','" + this.DropDownList9.SelectedItem.Value + "','" + this.DropDownList10.SelectedItem.Value + "','" + this.DropDownList11.SelectedItem.Value + "','" + this.DropDownList12.SelectedItem.Value + "','" + this.DropDownList13.SelectedItem.Value + "','" + this.DropDownList14.SelectedItem.Value + "','" + this.TextBox5.Text + "')";
        SqlCommand cmd = new SqlCommand(SQLCommand, cnn);
        try
        {
            cmd.ExecuteNonQuery();
            Response.Write("value saved successfully");
        }
        catch (Exception exception)
        {
            Response.Write("some error occured" + exception.Message);
        }
        cnn.Close();
        string message = "Your details have been saved successfully.";
        string script = "window.onload = function(){ alert('";
        script += message;
        script += "');";
        script += "window.location = '";
        script += Request.Url.AbsoluteUri;
        script += "'; }";
        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
    }
}
