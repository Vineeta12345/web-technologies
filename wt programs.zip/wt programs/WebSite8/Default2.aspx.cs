﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Name"] != null)
        {
            Label3.Text = Session["Name"].ToString();
        }
        if (Session["Email"] != null)
        {
            Label4.Text = Session["Email"].ToString();
        }
    }
}