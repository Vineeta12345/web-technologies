﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Net.Mail;
namespace MAil
{
    public partial class Sendmail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void SendMail()
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(txtTo.Text);

            mail.From = new MailAddress("vvineeta09@gmail.com");
            mail.Subject = "Email using Gmail";
            string Body = txtmessage.Text;
            mail.Body = Body;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
            smtp.Port = 587;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new System.Net.NetworkCredential
            ("username", "password");

            //Or your Smtp Email ID and Password
            smtp.EnableSsl = true;
            smtp.Send(mail);
        }
        protected void Bttn_Send_Click(object sender, EventArgs e)
        {
            SendMail();
        }
    }

}