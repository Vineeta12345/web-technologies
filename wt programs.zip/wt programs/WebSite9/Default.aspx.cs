﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;  

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("integrated security=true;Initial Catalog=Iare;Data Source=.");
    SqlCommand cmd; 
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        string s = "insert into order values(@p1,@p2,@p3,@p4)";
        con.Open();
        cmd = new SqlCommand(s, con);
        cmd.CommandType = CommandType.Text;
        cmd.Parameters.AddWithValue("@p1", TextFName.Text);
        cmd.Parameters.AddWithValue("@p2", TextLName.Text);
        cmd.Parameters.AddWithValue("@p3", TextCourse.Text);
        cmd.ExecuteNonQuery();
        con.Close();
    }  
}